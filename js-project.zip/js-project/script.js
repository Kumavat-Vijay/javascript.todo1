function pack() {
    var pack = document.getElementById('paste').value;
    var encodedStringBtoA = btoa(pack);
    document.getElementById('copy').innerHTML = encodedStringBtoA;
}

function clr() {
    document.getElementById('resetencode').reset();
}

function clr_copy(){
    document.getElementById('resetdecode').reset();
}

function cpy() {
    var encode = document.getElementById('copy').value;
    var encodedStringBtoA = atob(encode);
    document.getElementById('paste').innerHTML = encodedStringBtoA;
}

function mycopy() {
    var c = document.getElementById("paste");
    c.select();
    document.execCommand('copy');
}

function mycpy() {
    var c = document.getElementById("copy");
    c.select();
    document.execCommand('copy');
}
